using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using System.IO;
using Newtonsoft.Json;
using System;
using System.Text;


public class CommandExecutor : MonoBehaviour
{
    private Queue<System.Func<IEnumerator>> commands = new Queue<System.Func<IEnumerator>>(); // �R�}���h�L���[
    private Queue<CommandData> commandQueue = new Queue<CommandData>();
    List<RobotData> robotDataList = new List<RobotData>();
    private List<CommandData> commandList = new List<CommandData>();

    //public ScrollViewManager scrollViewManager;


    //public TMP_Text fileNameText;

    [System.Serializable]
    public class RobotData
    {
        public float speed;
        public float rotationSpeed;
        public string action;
        public float duration;
    }

    [System.Serializable]
    public class CommandData
    {
        public string commandType;
        //public float speed;
        //public float rotationSpeed;
        //public float duration;
        public float parameter;
    }

    [System.Serializable]
    public class RobotDataWrapper
    {
        public List<RobotData> robots; // JSON�ɕۑ����郊�X�g
    }
   



    public float currentSpeed = 1.0f;
    public float currentRotationSpeed = 0.0f;
    public string currentAction = "";
    public float currentDuration = 0.0f;
    public float speed = 0.0f;
    public float rotationSpeed = 0.0f;
    public float duration = 0.0f;
    //private Queue<CommandData> commandQueue = new Queue<CommandData>();
    //private List<RobotData> robotDataList = new List<RobotData>();





    [Header("Save/Load Settings")]
    public string saveFileName = "commands.json"; // �ۑ��t�@�C����


    [Header("Parameters")]
    public float movetime = 0.8f;  // �O�i�E��i�̈ړ�����
    public float rotateAngle = 90f;  // ��]�p�x
    public float moveSpeed = 1f;     // �ړ����x
    public float rotateSpeed = 45f;  // ��]���x

    //[Header("UI Elements")]
    
     

    public TMP_InputField speedInput;            // ���x���̓t�B�[���h
    public TMP_InputField timeInput;             // ���ԓ��̓t�B�[���h
    public TMP_InputField rotationSpeedInput;    // ��]���x���̓t�B�[���h


    private bool isExecuting = false; // ���s�����ǂ����̃t���O

    // �X�N���v�g�J�n���ɌĂ΂��
    private void Start()
    {
        //timeInput = timeInput.GetComponent<TMP_InputField>();
        //speedInput = speedInput.GetComponent<TMP_InputField>();
        //rotationSpeedInput = rotationSpeedInput.GetComponent<TMP_InputField>();
        // �eInputField�̃C�x���g���X�i�[�ݒ�

        if (timeInput != null)
        {
            timeInput.onEndEdit.AddListener(delegate { UpdateTime(); });
            Debug.Log("����");
        }

        if (speedInput != null)
            speedInput.onEndEdit.AddListener(delegate { UpdateSpeed(); });

        if (rotationSpeedInput != null)
            rotationSpeedInput.onEndEdit.AddListener(delegate { UpdaterotationSpeed(); });
        
            


    }

    // ���͒l�̔��f

    public void UpdateTime()
    {


        Debug.Log("�ł���");

        timeInput = timeInput.GetComponent<TMP_InputField>();

        
        Debug.Log("�ł���");
        //////
        if (float.TryParse(timeInput.text, out currentDuration))
            Debug.Log("Time: " + currentDuration);
        else
            Debug.LogWarning("Invalid input for time");
        /////
    }


    public void UpdateSpeed()
    {
        
        ///////
        if (float.TryParse(speedInput.text, out moveSpeed))
            Debug.Log("Move Speed: " + moveSpeed);
        else
            Debug.LogWarning("Invalid input for speed");
        ///////
    }

    public void UpdaterotationSpeed()
    {
        float.TryParse(rotationSpeedInput.text, out rotateAngle);
        //////
        if (float.TryParse(rotationSpeedInput.text, out currentRotationSpeed))
            Debug.Log("Rotate Angle: " + currentRotationSpeed);
        else
            Debug.LogWarning("Invalid input for angle");
        //////
        ///
    }

    // �u�O�i�v�R�}���h���L���[�ɒǉ�
    public void AddMoveForward()
    {
        foreach (var data in robotDataList)
        {
            Debug.Log($"���X�g�̃f�[�^: Action: {data.action}, Speed: {data.speed}, Rotation Speed: {data.rotationSpeed}, Duration: {data.duration}");
        }
        RecordRobotData(currentSpeed, rotationSpeed, "MoveForward", currentDuration);

        SaveToJson();





        commands.Enqueue(MoveForward);
        string queueContents = string.Join(", ", commands);
        
    }

    // �u��i�v�R�}���h���L���[�ɒǉ�
    public void AddMoveBackward()
    {
        RecordRobotData(currentSpeed, rotationSpeed, "MoveBackward", currentDuration);
        commands.Enqueue(MoveBackward);
        SaveToJson();
    }

    // �u�E��]�v�R�}���h���L���[�ɒǉ�
    public void AddRotateRight()
    {
        RecordRobotData(currentSpeed, rotationSpeed, "RotateRight", currentDuration);
        commands.Enqueue(() => RotateObject(Vector3.up));
        SaveToJson();
    }

    // �u����]�v�R�}���h���L���[�ɒǉ�
    public void AddRotateLeft()
    {
        RecordRobotData(currentSpeed, rotationSpeed, "RotateLeft", currentDuration);
        commands.Enqueue(() => RotateObject(Vector3.down));
        SaveToJson();
        
    }

    // ���s�{�^���������ꂽ�Ƃ��ɃL���[�̃R�}���h���������s
    public void StartExecution()
    {
        if (!isExecuting)
        {
            isExecuting = true;
            StartCoroutine(ExecuteCommands());
        }
    }

    // �O�i�����i�R���[�`���j
    private IEnumerator MoveForward()
    {
        float distanceMoved = 0f;
        while (distanceMoved < movetime * moveSpeed)
        {
            float moveStep = moveSpeed * Time.deltaTime;
            transform.Translate(Vector3.forward * moveStep);
            distanceMoved += moveStep;
            yield return null;
        }
    }

    // ��i�����i�R���[�`���j
    private IEnumerator MoveBackward()
    {
        float distanceMoved = 0f;
        while (distanceMoved < movetime * moveSpeed)
        {
            float moveStep = moveSpeed * Time.deltaTime;
            transform.Translate(Vector3.back * moveStep);
            distanceMoved += moveStep;
            yield return null;
        }
    }

    // ��]�����i�R���[�`���j
    private IEnumerator RotateObject(Vector3 rotationDirection)
    {
        float angleRotated = 0f;
        while (angleRotated < rotateAngle)
        {
            float rotateStep = rotateSpeed * Time.deltaTime;
            transform.Rotate(rotationDirection, rotateStep);
            angleRotated += rotateStep;
            yield return null;
        }
    }

    // �L���[�ɒǉ����ꂽ�R�}���h���������s
    private IEnumerator ExecuteCommands()
    {
        while (commands.Count > 0)
        {
            var command = commands.Dequeue();
            yield return command(); // �R�}���h�����s���A�����܂őҋ@
        }

        isExecuting = false; // ���s�I����Ƀt���O�����Z�b�g
    }

    public void RecordRobotData(float speed, float rotationSpeed, string action, float duration)
    {
        
        RobotData data = new RobotData
        {
            speed = speed,
            rotationSpeed = rotationSpeed,
            action = action,
            duration = duration
        };
        robotDataList.Add(data);

       

    }
    



    public void SaveToJson()
    {
        string json = JsonConvert.SerializeObject(robotDataList, Formatting.Indented);
        File.WriteAllText("commands.json", json);
        Debug.Log($"�������ꂽJSON: {json}");



        



    /*
    // �f�[�^���b�p�[���쐬���ă��X�g����
    RobotDataWrapper wrapper = new RobotDataWrapper
    {
        robots = robotDataList
    };

    // JSON������ɕϊ�
    string json = JsonUtility.ToJson(wrapper, true);
    Debug.Log($"�������ꂽJSON: {json}");

    // �t�@�C���ɕۑ�
    string filePath = Path.Combine(Application.persistentDataPath, saveFileName);
    File.WriteAllText(filePath, json);

    Debug.Log($"���{�b�g�f�[�^���ۑ�����܂���: {filePath}");

    foreach (var data in robotDataList)
    {
        Debug.Log($"Action: {data.action}, Speed: {data.speed}, Rotation Speed: {data.rotationSpeed}, Duration: {data.duration}");
    }
    */
}





    /*
    public void EndAction()
    {

        float actionDuration = currentDuration;
        RecordRobotData(currentSpeed, currentRotationSpeed, currentAction, actionDuration);
        SaveCommandsToJson();

    }

    public void RecordRobotData(float speed, float rotationSpeed, string action, float duration)
    {
        RobotData data = new RobotData
        {
            speed = speed,
            rotationSpeed = rotationSpeed,
            action = action,
            duration = duration
        };
        robotDataList.Add(data);
    }

    public void SaveCommandsToJson()
    {
        // �L���[�����X�g�ɕϊ�
        List<CommandData> commandList = new List<CommandData>(commands);

        commandList = ConvertRobotDataToCommandData(robotDataList);

        // ���X�g�����b�v����I�u�W�F�N�g���쐬
        CommandListWrapper wrapper = new CommandListWrapper
        {
            commandList = robotDataList
        };

        // ���X�g��JSON������ɕϊ�
        string json = JsonUtility.ToJson(wrapper, true);

        // JSON���t�@�C���ɕۑ�
        string filePath = Path.Combine(Application.persistentDataPath, saveFileName);
        File.WriteAllText(filePath, json);

        Debug.Log($"�R�}���h��JSON�t�@�C���ɕۑ�����܂���: {filePath}");
    }



    private List<CommandData> ConvertRobotDataToCommandData(List<RobotData> robotDataList)
    {
        List<CommandData> commandList = new List<CommandData>();

        foreach (var robotData in robotDataList)
        {
            commandList.Add(new CommandData
            {
                commandType = robotData.action,
                parameter = robotData.speed
                //duration = robotData.duration,
                //speed = robotData.speed,
                //rotationSpeed = robotData.rotationSpeed


            });
        }

        return commandList;
    }
   */

}
